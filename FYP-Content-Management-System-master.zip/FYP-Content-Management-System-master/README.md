# MERN STACK CONTENT MANAGEMENT SYSTEM

## Frontend 

### Dependencies
    React-Router V6
    History
    React Slik Carousel
    React Photo Gallery
    React Images v 1.1.7
    React MarkDown 
    
### Deployment
    Link : https://epo.org.pk
    Link : https://cms-fyp.netlify.app/

## Backend
    MongoDB Atlas
    Express
    Node
## Admin
    Strapi JS
   
   ### Components
        Blogs
        Users
        Admins
        
## Author
