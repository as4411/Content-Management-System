import img1 from '../../images/gallery/1.jpg'
import img2 from '../../images/gallery/2.jpg'
import img3 from '../../images/gallery/3.jpg'
import img4 from '../../images/gallery/4.jpg'
import img5 from '../../images/gallery/5.jpg'
import img6 from '../../images/gallery/6.jpg'
import img7 from '../../images/gallery/7.jpg'
import img8 from '../../images/gallery/8.jpg'
import img9 from '../../images/gallery/9.jpg'
export const photos = [
    {
      src: img1,
      width: 4,
      height: 3
    },
    {
      src: img2,
      width: 1,
      height: 1
    },
    {
      src: img3,
      width: 3,
      height: 4
    },
    {
      src: img4,
      width: 3,
      height: 4
    },
    {
      src: img5,
      width: 3,
      height: 4
    },
    {
      src: img6,
      width: 4,
      height: 3
    },
    {
      src: img7,
      width: 3,
      height: 4
    },
    {
      src: img8,
      width: 4,
      height: 3
    },
    {
      src: img9,
      width: 4,
      height: 3
    }
  ];
  